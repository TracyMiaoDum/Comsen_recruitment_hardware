/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include "lcd1602.h"
#include "ttp229.h"
#include <stdio.h>
#include "stm32f1xx_hal_uart.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "calculator_app.h"
#include "usb_device.h"
#include "usbd_cdc_if.h"

/* 1 = 同时启用 USB 虚拟串口（CDC）；出问题改成 0 就回到纯 USART1 */
#define USE_USB_CDC 1
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
typedef StaticTask_t osStaticThreadDef_t;
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim3;

/* Definitions for defaultTask */

/* Definitions for KeyTask */

/* USER CODE BEGIN PV */
char line1[17] = "Debug Mode      ";
char line2[17];
UART_HandleTypeDef huart1;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM3_Init(void);
void StartDefaultTask(void *argument);
void KeyTaskFunc(void *argument);
void lcdTaskFunc(void *argument);
void calculatorTaskFunc(void *argument);
void controllerTaskFunc(void *argument);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// 串口1初始化函数 (PA9 TX, PA10 RX)
void MX_USART1_UART_Init(void)
{
    huart1.Instance = USART1;
    huart1.Init.BaudRate = 115200;
    huart1.Init.WordLength = UART_WORDLENGTH_8B;
    huart1.Init.StopBits = UART_STOPBITS_1;
    huart1.Init.Parity = UART_PARITY_NONE;
    huart1.Init.Mode = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK)
    {
        Error_Handler();
    }
}

// 重定向 printf：同时发 USART1 和 USB CDC（哪个通用哪个）
#ifdef __GNUC__
int _write(int file, char* ptr, int len) {
    (void)file;
    HAL_UART_Transmit(&huart1, (uint8_t*)ptr, len, HAL_MAX_DELAY);
#if USE_USB_CDC
    CDC_Transmit_FS((uint8_t*)ptr, (uint16_t)len);   /* 未枚举时立即返回失败，不阻塞 */
#endif
    return len;
}
#endif

/* ===== 读取范围：全部 30 个键 =====
 *   U1（上三行 T0..T14）+ U2（下三行 T15..T29）
 * 若只想用 U1，把下面改成 0x7FFFu。
 * 注：U2 的读数若异常，会被"动态屏蔽"（连续 5 秒为 1）自动剔除。 */
#define TTP_ALL_MASK 0x3FFFFFFFu

/* 开机就屏蔽的已知坏通道（想恢复某个键，把它从这行去掉）
 *   bit0 = SHIFT、bit3 = UP、bit5 = "(" —— 这三个一直在抖 */
#define TTP_BAD_MASK  ((1u << 0) | (1u << 3) | (1u << 5))

/* ===== 模式开关 =====
 *   1 = 全键打印调试版（不打印、不滤波，只往串口打）
 *   0 = 计算器版（屏 + 触摸键 + 串口都能用）  */
#define MODE_KEYDUMP 0

/* ===== LCD 自检模式 =====
 *   1 = 只做 LCD 自检：打印 6 根线的通断自检 + 每 2 秒刷一次屏
 *   0 = 正常（计算器） */
#define MODE_LCDTEST 0

/* ===== 数据极性 =====
 *   0 = 1 表示"按下"（旧板验证过）
 *   1 = 取反：1 表示"未按下"
 * 判断方法：dump 模式下什么都不按，
 *   读到大量 1（如 0x3FFF....）→ 改成 1；
 *   读到 0x00000000          → 保持 0。 */
#define TTP_INVERT 0

/* ===== 两线时序扫描模式 =====
 *   1 = 用自己写的读取去试芯片，打印 3 组对照（不需要示波器）
 *   0 = 正常（计算器） */
#define MODE_TTPSCAN 0

/* ===== 触摸输入总开关 =====
 *   0 = 启用触摸键（本板读数异常，暂关闭）
 *   1 = 关闭：只接受串口 / USB-CDC 输入，屏照常工作 */
#define TTP_NO_TOUCH 1

/* 统一的读取入口：所有地方都用它，方便切极性 / 关闭触摸 */
static uint32_t ttp_read(void)
{
#if TTP_NO_TOUCH
    return 0u;
#else
    uint32_t v = ttp229_read_physical();

#if TTP_INVERT
    v = ~v;
#endif
    return v;
#endif
}

#if MODE_TTPSCAN
static uint32_t scan_beat = 0u;

/* 约 5 us 的粗糙延时（72 MHz 下空循环） */
static void ttp_dly(void)
{
    volatile uint32_t i;
    for (i = 0u; i < 60u; i++) { }
}

/* 自己实现的两线读取：U1 的 SCL = PB6，SDO = PB7
 * sample_on_low = 0：在 SCL 上升沿之后采样
 * sample_on_low = 1：在 SCL 为低电平时采样
 * 返回 16 位（低 15 位是按键） */
static uint32_t ttp_myread(uint8_t sample_on_low)
{
    uint32_t v = 0u;
    uint8_t i;

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);      /* 空闲高 */
    ttp_dly(); ttp_dly();

    for (i = 0u; i < 16u; i++) {
        v <<= 1;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
        ttp_dly();
        if (sample_on_low) {
            if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_7) == GPIO_PIN_SET) v |= 1u;
        }
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
        ttp_dly();
        if (!sample_on_low) {
            if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_7) == GPIO_PIN_SET) v |= 1u;
        }
    }
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
    return v;
}
#endif

#if MODE_KEYDUMP
static uint32_t dump_last = 0u;
static uint32_t dump_beat = 0u;
static uint32_t dump_counts[30];
#endif

/* 动态屏蔽：某通道连续 5 秒（500 拍）为 1 -> 判为坏通道并永久屏蔽 */
static uint16_t on_cnt[30];

/* 30 个键名：T0..T14 = U1（上三行），T15..T29 = U2（下三行） */
static const char *const key_name[30] = {
    /* U1 */
    "SHIFT", "BACK", "MODE", "UP", "OK",
    "(", ")", "LEFT", "DOWN", "RIGHT",
    "7", "8", "9", "DEL", "AC",
    /* U2 */
    "4", "5", "6", "*", "/",
    "1", "2", "3", "+", "-",
    "0", ".", "E10", "FMT", "EXE"
};

static void print_mask(const char *tag, uint32_t m)
{
    int first = 1;
    printf("%s=0x%08X keys=", tag, (unsigned)m);
    for (uint32_t i = 0; i < 30u; i++) {
        if ((m >> i) & 1u) { printf("%s%s", first ? "" : ",", key_name[i]); first = 0; }
    }
    if (first) printf("none");
    printf("\r\n");
}

/* 只认"恰好一个键、且连续 8 帧（约 80 ms）不变" —— 抗串扰、抗闪 */
static uint32_t stable_single(uint32_t now)
{
    static uint32_t out = 0u;
    static uint8_t  n = 0u;

    if (now != 0u && (now & (now - 1u)) == 0u) {   /* 恰好一位为 1 */
        if (now == out) { if (n < 8u) n++; }
        else            { out = now; n = 0u; }
    } else {                                       /* 0 或 多位同时为 1 */
        if (now == 0u) { out = 0u; }
        n = 0u;
    }
    return (n >= 8u) ? out : 0u;
}

/* ================= 四则运算计算器 ================= */
#define EXPR_MAX 63
static char    expr_buf[EXPR_MAX + 1];
static uint8_t expr_len = 0u;
static const char *expr_p;
static uint8_t expr_err;                 /* 0=正常  1=语法错  2=除零 */

static void expr_clear(void) { expr_len = 0u; expr_buf[0] = '\0'; }
static void skip_space(void) { while (*expr_p == ' ') expr_p++; }

static double parse_expr(void);

/* number ::= digit+ ('.' digit*)? */
static double parse_number(void)
{
    double v = 0.0;
    int digits = 0;

    skip_space();
    while (*expr_p >= '0' && *expr_p <= '9') {
        v = v * 10.0 + (double)(*expr_p - '0');
        expr_p++; digits++;
    }
    if (*expr_p == '.') {
        double f = 0.1;
        expr_p++;
        while (*expr_p >= '0' && *expr_p <= '9') {
            v += (double)(*expr_p - '0') * f;
            f *= 0.1; expr_p++; digits++;
        }
    }
    if (digits == 0) expr_err = 1u;
    return v;
}

/* factor ::= number | '(' expr ')' | '-' factor | '+' factor */
static double parse_factor(void)
{
    double v;

    skip_space();
    if (*expr_p == '(') {
        expr_p++;
        v = parse_expr();
        skip_space();
        if (*expr_p == ')') expr_p++; else expr_err = 1u;
        return v;
    }
    if (*expr_p == '-') { expr_p++; return -parse_factor(); }
    if (*expr_p == '+') { expr_p++; return  parse_factor(); }
    return parse_number();
}

/* term ::= factor (('*'|'/') factor)* */
static double parse_term(void)
{
    double v = parse_factor();

    for (;;) {
        char c;
        skip_space();
        c = *expr_p;
        if (c == '*') { expr_p++; v *= parse_factor(); }
        else if (c == '/') {
            double d;
            expr_p++;
            d = parse_factor();
            if (d == 0.0) expr_err = 2u; else v /= d;
        } else break;
    }
    return v;
}

/* expr ::= term (('+'|'-') term)* */
static double parse_expr(void)
{
    double v = parse_term();

    for (;;) {
        char c;
        skip_space();
        c = *expr_p;
        if (c == '+') { expr_p++; v += parse_term(); }
        else if (c == '-') { expr_p++; v -= parse_term(); }
        else break;
    }
    return v;
}

/* 把 double 转成字符串（不用 %f：nano 库默认不支持浮点 printf） */
static void fmt_num(double v, char *out, uint8_t maxlen)
{
    uint32_t scaled, ip, fp;
    uint8_t n = 0u;

    if (v < 0.0) { out[n++] = '-'; v = -v; }
    if (v > 1000000.0) { out[0] = 'E'; out[1] = 'R'; out[2] = 'R'; out[3] = '\0'; return; }

    scaled = (uint32_t)(v * 10000.0 + 0.5);
    ip = scaled / 10000u;
    fp = scaled % 10000u;

    {   /* 整数部分 */
        char t[12];
        uint8_t k = 0u;
        if (ip == 0u) t[k++] = '0';
        while (ip != 0u) { t[k++] = (char)('0' + (ip % 10u)); ip /= 10u; }
        while (k > 0u && n < (uint8_t)(maxlen - 1u)) out[n++] = t[--k];
    }
    if (fp != 0u && n < (uint8_t)(maxlen - 2u)) {   /* 小数部分，去掉末尾 0 */
        char d[4];
        int last = 3;
        for (int i = 3; i >= 0; i--) { d[i] = (char)('0' + (fp % 10u)); fp /= 10u; }
        while (last >= 0 && d[last] == '0') last--;
        out[n++] = '.';
        for (int i = 0; i <= last && n < (uint8_t)(maxlen - 1u); i++) out[n++] = d[i];
    }
    out[n] = '\0';
}

/* ================= LCD1602 显示 ================= */
#define USE_LCD 1                 /* 屏幕还没修好就先改成 0 */

static char lcd_res[17];          /* 第二行：最近一次结果 */

static void set_lcd_res(const char *s)
{
    uint8_t i;
    for (i = 0u; i < 16u && s[i] != '\0'; i++) lcd_res[i] = s[i];
    for (; i < 17u; i++) lcd_res[i] = '\0';
}

#if USE_LCD
static void lcd_render(void)
{
    char a[16], b[16];
    uint8_t i, start = 0u;

    if (expr_len > 15u) start = (uint8_t)(expr_len - 15u);   /* 太长时显示尾部 */
    for (i = 0u; i < 16u; i++) {
        uint8_t p = (uint8_t)(start + i);
        a[i] = (p < expr_len) ? expr_buf[p] : ' ';
    }
    {   /* 用下划线标出输入位置 */
        uint8_t pos = (uint8_t)(expr_len - start);
        if (pos < 16u) a[pos] = '_';
    }
    for (i = 0u; i < 16u; i++) b[i] = (lcd_res[i] != '\0') ? lcd_res[i] : ' ';
    lcd1602_write_lines(a, b);
}
#define LCD_RENDER()   lcd_render()
#define LCD_INIT()     lcd1602_init()
#else
#define LCD_RENDER()   ((void)0)
#define LCD_INIT()     ((void)0)
#endif

/* 求值并打印 */
static void do_eval(void)
{
    double v;

    if (expr_len == 0u) return;
    expr_p = expr_buf;
    expr_err = 0u;
    v = parse_expr();
    skip_space();
    if (expr_err == 1u || *expr_p != '\0') {
        printf("\r\n> %s   [syntax error]\r\n", expr_buf);
        set_lcd_res("ERR SYNTAX");
    } else if (expr_err == 2u) {
        printf("\r\n> %s   [divide by zero]\r\n", expr_buf);
        set_lcd_res("ERR DIV/0");
    } else {
        char s[20], t[17];
        uint8_t i;
        fmt_num(v, s, (uint8_t)sizeof(s));
        printf("\r\n> %s = %s\r\n", expr_buf, s);
        t[0] = '='; t[1] = ' ';
        for (i = 0u; i < 14u && s[i] != '\0'; i++) t[2 + i] = s[i];
        t[2 + i] = '\0';
        set_lcd_res(t);
    }
}

/* 输入一个字符（串口和触摸键共用） */
static void input_char(char c)
{
    if (c == '\r' || c == '\n') { do_eval(); expr_clear(); printf("calc> "); LCD_RENDER(); return; }
    if (c == 8 || c == 127) {
        if (expr_len > 0u) { expr_len--; expr_buf[expr_len] = '\0'; printf("\b \b"); LCD_RENDER(); }
        return;
    }
    if (c == 'C' || c == 'c') { expr_clear(); printf("\r\ncalc> "); LCD_RENDER(); return; }
    if ((c >= '0' && c <= '9') || c == '.' || c == '+' || c == '-' ||
        c == '*' || c == '/' || c == '(' || c == ')') {
        if (expr_len < EXPR_MAX) { expr_buf[expr_len++] = c; expr_buf[expr_len] = '\0'; printf("%c", c); LCD_RENDER(); }
    }
}

/* ---- 串口接收：中断 + 环形缓冲 ---- */
#define RXBUF_SIZE 128u
static volatile uint8_t  rxbuf[RXBUF_SIZE];
static volatile uint16_t rx_head = 0u, rx_tail = 0u;
static uint8_t rx_byte;

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1) {
        uint16_t nx = (uint16_t)((rx_head + 1u) % RXBUF_SIZE);
        if (nx != rx_tail) { rxbuf[rx_head] = rx_byte; rx_head = nx; }
        HAL_UART_Receive_IT(&huart1, &rx_byte, 1u);
    }
}

static int serial_getc(void)
{
    uint8_t c;

    if (rx_tail == rx_head) return -1;
    c = rxbuf[rx_tail];
    rx_tail = (uint16_t)((rx_tail + 1u) % RXBUF_SIZE);
    return (int)c;
}

#if USE_USB_CDC
/* 由 usbd_cdc_if.c 的 CDC_Receive_FS 调用：USB 收到的字节塞进同一个环形缓冲 */
void usb_cdc_rx(const uint8_t *buf, uint32_t len)
{
    uint32_t i;

    for (i = 0u; i < len; i++) {
        uint16_t nx = (uint16_t)((rx_head + 1u) % RXBUF_SIZE);
        if (nx != rx_tail) { rxbuf[rx_head] = buf[i]; rx_head = nx; }
    }
}
#endif

/* ---- 触摸键 -> 字符/动作（U1 的 15 个键） ---- */
static char key_to_char(uint32_t bit)
{
    switch (bit) {
        case (1u << 10): return '7';    /* 7   */
        case (1u << 11): return '8';    /* 8   */
        case (1u << 12): return '9';    /* 9   */
        case (1u << 5):  return '(';    /* (   */
        case (1u << 6):  return ')';    /* )   */
        case (1u << 3):  return '+';    /* UP    */
        case (1u << 8):  return '-';    /* DOWN  */
        case (1u << 7):  return '*';    /* LEFT  */
        case (1u << 9):  return '/';    /* RIGHT */
        case (1u << 4):  return '\r';   /* OK    =  计算 */
        case (1u << 13): return 8;      /* DEL   =  退格 */
        case (1u << 1):  return 8;      /* BACK  =  退格 */
        case (1u << 14): return 'C';    /* AC    =  清空 */
        case (1u << 2):  return '+';    /* MODE  =  "+"（UP 已屏蔽，用它当加号） */
        /* ---- U2（下三行，芯片已拆除，映射保留备用） ---- */
        case (1u << 15): return '4';
        case (1u << 16): return '5';
        case (1u << 17): return '6';
        case (1u << 18): return '*';    /* × */
        case (1u << 19): return '/';    /* ÷ */
        case (1u << 20): return '1';
        case (1u << 21): return '2';
        case (1u << 22): return '3';
        case (1u << 23): return '+';
        case (1u << 24): return '-';
        case (1u << 25): return '0';
        case (1u << 26): return '.';
        case (1u << 27): return 'C';    /* ×10ˣ : 暂作清空 */
        case (1u << 28): return 'C';    /* FMT  : 暂作清空 */
        case (1u << 29): return '\r';   /* EXE  = 计算 */
        default:         return 0;
    }
}

/* ================= LCD 自检（MODE_LCDTEST） ================= */
#if MODE_LCDTEST
static uint32_t lcd_beat = 0u;

/* 把 6 根 LCD 线分别拉高/拉低并读回：读回与驱动不一致 => 短路/断线 */
static void lcd_pin_test(void)
{
    static const uint16_t pins[6] = { GPIO_PIN_10, GPIO_PIN_11, GPIO_PIN_12,
                                      GPIO_PIN_13, GPIO_PIN_14, GPIO_PIN_15 };
    static const char *const nm[6] = { "RS/PB10", "E /PB11", "D4/PB12",
                                       "D5/PB13", "D6/PB14", "D7/PB15" };
    uint8_t i;

    printf("---- LCD pin test (drive hi/lo, read back) ----\r\n");
    for (i = 0u; i < 6u; i++) {
        uint8_t hi, lo;
        HAL_GPIO_WritePin(GPIOB, pins[i], GPIO_PIN_SET);
        HAL_Delay(2);
        hi = (HAL_GPIO_ReadPin(GPIOB, pins[i]) == GPIO_PIN_SET) ? 1u : 0u;
        HAL_GPIO_WritePin(GPIOB, pins[i], GPIO_PIN_RESET);
        HAL_Delay(2);
        lo = (HAL_GPIO_ReadPin(GPIOB, pins[i]) == GPIO_PIN_SET) ? 1u : 0u;
        printf(" %s  hi=%u lo=%u  %s\r\n", nm[i], (unsigned)hi, (unsigned)lo,
               (hi == 1u && lo == 0u) ? "OK" : "FAIL");
    }
    printf(" V0 = 3.3V*1k/(15k+1k) = 0.21V  (1602 usually needs 0.3~1.0V)\r\n");
}
#endif
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
  MX_USART1_UART_Init();
#if USE_USB_CDC
  MX_USB_DEVICE_Init();          /* 启用 USB 虚拟串口（CDC） */
#endif
  printf("\r\n=== Comsen Serial port button debugging ===\r\n");
  printf("Ready, please touch the button ...\r\n");
  if (HAL_TIM_Base_Start(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  /* 尽早初始化屏幕：开机立刻有提示，不用等基线采样那 3 秒 */
  LCD_INIT();
  lcd1602_write_lines("1234567890123456", "ABCDEFGHIJKLMNOP");
  /* USER CODE END 2 */

  /* Init scheduler */
  //osKernelInitialize();//就是这行。以上的内容是初始化代码，以下的内容是RTOS调度器（多任务系统）。
  /*简化版：while(1){按键是否被按下；接受*/

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  //calculator_app_init();
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  //defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* creation of KeyTask */
  //KeyTaskHandle = osThreadNew(KeyTaskFunc, NULL, &KeyTask_attributes);

  /* creation of lcdTask */
  //lcdTaskHandle = osThreadNew(lcdTaskFunc, NULL, &lcdTask_attributes);

  /* creation of calculatorTask */
  //calculatorTaskHandle = osThreadNew(calculatorTaskFunc, NULL, &calculatorTask_attributes);

  /* creation of controllerTask */
  //controllerTaskHandle = osThreadNew(controllerTaskFunc, NULL, &controllerTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  //osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  /* 一次性初始化与基线采样：只在进入下面的 while 循环前执行一次，等效于 USER CODE 2 */

  setvbuf(stdout, NULL, _IONBF, 0);
  printf("\r\n=== key baseline test ===\r\n");
  /* 等 2 秒再采基线：给"按复位的那根手指"离开板子的时间，
     否则手指会被 TTP229 当成"一直按着"，那批通道就全被屏蔽了 */
  HAL_Delay(2000);

  /* 采样 1 秒取"与"：只有一直为 1 的通道才算真卡住（闪烁的不算） */
  uint32_t raw = 0u;
  uint32_t dead = TTP_ALL_MASK;
  for (uint32_t i = 0; i < 100u; i++) {
      raw = ttp_read() & TTP_ALL_MASK;
      dead &= raw;
      HAL_Delay(10);
  }
  dead |= TTP_BAD_MASK;                            /* 叠加已知坏通道 */
  printf("raw(last)=0x%08X  ", (unsigned)raw);
  print_mask("dead(stuck+known-bad, ignored)", dead);

  uint32_t next = HAL_GetTick() + 10u;
  uint32_t confirmed = 0u;                         /* 去抖后的有效按键 */

  /* 开串口接收中断 */
  HAL_UART_Receive_IT(&huart1, &rx_byte, 1u);

#if MODE_KEYDUMP
  dump_last = ttp_read() & 0x3FFFFFFFu;
  dump_beat = HAL_GetTick() + 5000u;
  printf("\r\n=== KEY DUMP: all channels, no filter, no mask ===\r\n");
  printf("Press ONE key at a time; every changed bit is printed.\r\n");
#else
  LCD_INIT();                       /* 屏没修好也不会影响串口 */
  set_lcd_res("READY");             /* 开机第二行给个提示 */
  LCD_RENDER();
  printf("\r\n=== CALCULATOR (4 operations + parentheses) ===\r\n");
  printf("Input 1: USART1 / USB-CDC  - type an expression then Enter\r\n");
  printf("Input 2: touch  7 8 9 | MODE=+ DOWN=- LEFT=* RIGHT=/ | OK== | DEL=back | AC=clear\r\n");
  printf("calc> ");
#endif

#if MODE_LCDTEST
  lcd_pin_test();
  lcd1602_init();
  lcd1602_write_lines("LCD TEST  OK    ", "0123456789ABCDEF");
  printf("[LCD] init done, pattern refreshed every 2s\r\n");
  lcd_beat = HAL_GetTick() + 2000u;
#endif

  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
      if ((int32_t)(HAL_GetTick() - next) >= 0) {
          next += 10u;

#if MODE_KEYDUMP
          {   /* ---- 全键打印：30 个通道全开，不屏蔽、不滤波 ---- */
              uint32_t now  = ttp_read() & 0x3FFFFFFFu;
              uint32_t down = now & ~dump_last;
              uint32_t up   = dump_last & ~now;
              uint32_t i;

              for (i = 0; i < 30u; i++) {
                  if (down & (1u << i)) {
                      dump_counts[i]++;
                      printf("[DOWN] %-6s bit%-2u bmp=0x%08X\r\n",
                             key_name[i], (unsigned)i, (unsigned)now);
                  }
              }
              for (i = 0; i < 30u; i++) {
                  if (up & (1u << i)) printf("[UP  ] %s\r\n", key_name[i]);
              }
              dump_last = now;
          }
#elif MODE_LCDTEST
          /* LCD 自检模式：不读按键、不碰屏，屏幕交给下面的 LCDTEST 块独占 */
#elif MODE_TTPSCAN
          /* 时序扫描模式：不处理按键，扫描在下面的独立块里 */
#else
          /* 1) 串口输入 */
          int ch;
          while ((ch = serial_getc()) >= 0) input_char((char)ch);

          /* 2) 触摸键：全 30 位 + 动态屏蔽 + 单键 80 ms 稳定 */
          uint32_t raw_all = ttp_read() & TTP_ALL_MASK;
          uint32_t i;

          for (i = 0; i < 30u; i++) {
              if (raw_all & (1u << i)) {
                  if (on_cnt[i] < 500u) on_cnt[i]++;
                  if (on_cnt[i] >= 500u && (dead & (1u << i)) == 0u) {   /* 连续 5 秒，且还没屏蔽过 */
                      dead |= (1u << i);
                      printf("\r\n[mask] %s 连续 5 秒为 1，已屏蔽\r\ncalc> %s", key_name[i], expr_buf);
                  }
              } else {
                  on_cnt[i] = 0u;
              }
          }

          uint32_t now = raw_all & ~dead;
          uint32_t k = stable_single(now);
          if (k != confirmed) {
              confirmed = k;
              if (k != 0u) {
                  char c = key_to_char(k);
                  if (c != 0) input_char(c);
              }
          }
#endif
      }
#if MODE_KEYDUMP
      if ((int32_t)(HAL_GetTick() - dump_beat) >= 0) {   /* 每 5 秒打一次累计 */
          uint32_t i;
          dump_beat += 5000u;
          printf("---- 5s count (U1: T0..T14) ----\r\n");
          for (i = 0; i < 15u; i++) printf(" %s:%u", key_name[i], (unsigned)dump_counts[i]);
          printf("\r\n");
          printf("---- 5s count (U2: T15..T29) ----\r\n");
          for (i = 15u; i < 30u; i++) printf(" %s:%u", key_name[i], (unsigned)dump_counts[i]);
          printf("\r\n");
      }
#endif
#if MODE_LCDTEST
      if ((int32_t)(HAL_GetTick() - lcd_beat) >= 0) {
          /* 走字测试：一个 '8' 在 15 个位置上移动
           * 走起来 => 地址自增正常；停在原位 => 初始化/地址计数器有问题 */
          static uint8_t pos = 0u;
          char l1[16], l2[16];
          uint8_t i;

          lcd_beat += 500u;
          for (i = 0u; i < 16u; i++) { l1[i] = ' '; l2[i] = ' '; }
          l1[0] = '1';                       /* 固定 1 号位，方便看有没有乱 */
          l1[pos] = '8';
          lcd1602_write_lines(l1, l2);
          printf("[LCD] pos=%u\r\n", (unsigned)pos);
          pos = (uint8_t)((pos + 1u) % 15u);
      }
#endif
#if MODE_TTPSCAN
      if ((int32_t)(HAL_GetTick() - scan_beat) >= 0) {
          uint32_t a, b, c;
          uint8_t idle;

          scan_beat += 500u;
          a = ttp_myread(0u);                        /* 上升沿后采样 */
          b = ttp_myread(1u);                        /* 低电平时采样 */
          c = ttp229_read_physical() & 0x7FFFu;      /* 库的结果做对照 */
          idle = (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_7) == GPIO_PIN_SET) ? 1u : 0u;
          printf("[SCAN] rise=0x%04X low=0x%04X lib=0x%04X sdo_idle=%u\r\n",
                 (unsigned)a, (unsigned)b, (unsigned)c, (unsigned)idle);
      }
#endif
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USB;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLL_DIV1_5;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 71;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13
                          |GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6|GPIO_PIN_8, GPIO_PIN_SET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PB10 PB11 PB12 PB13
                           PB14 PB15 PB6 PB8 */
  GPIO_InitStruct.Pin = GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13
                          |GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_6|GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PB7 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_7|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */


/* USER CODE BEGIN Header_KeyTaskFunc */
/**
* @brief Function implementing the KeyTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_KeyTaskFunc */

/* USER CODE BEGIN Header_lcdTaskFunc */
/**
* @brief Function implementing the lcdTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_lcdTaskFunc */


/* USER CODE BEGIN Header_calculatorTaskFunc */
/**
* @brief Function implementing the claculatorTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_calculatorTaskFunc */
void calculatorTaskFunc(void *argument)
{
  /* USER CODE BEGIN calculatorTaskFunc */
  (void)argument;
  calculator_compute_task();
  /* USER CODE END calculatorTaskFunc */
}

/* USER CODE BEGIN Header_controllerTaskFunc */
/**
* @brief Function implementing the controllerTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_controllerTaskFunc */
void controllerTaskFunc(void *argument)
{
  /* USER CODE BEGIN controllerTaskFunc */
  (void)argument;
  calculator_controller_task();
  /* USER CODE END controllerTaskFunc */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM4 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM4) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
